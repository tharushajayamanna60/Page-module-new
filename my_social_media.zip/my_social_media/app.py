from flask import Flask, render_template, request, redirect, url_for, abort
from models import db, User
from pages import PageManager

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///social_media.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# --- Fake user simulation ---
# In real app, use auth. Here we just create a user for testing.
@app.before_first_request
def create_tables_and_user():
    db.create_all()
    if not User.query.filter_by(username="testuser").first():
        user = User(username="testuser")
        db.session.add(user)
        db.session.commit()

def get_current_user():
    return User.query.filter_by(username="testuser").first()

# --- Routes ---

@app.route('/')
def index():
    user = get_current_user()
    pages = PageManager.list_pages_by_owner(user.id)
    return render_template('index.html', pages=pages, user=user)

@app.route('/page/create', methods=['GET', 'POST'])
def create_page():
    user = get_current_user()
    if request.method == 'POST':
        name = request.form['name']
        description = request.form.get('description', '')
        profile_img_url = request.form.get('profile_img_url', '')
        cover_img_url = request.form.get('cover_img_url', '')
        page = PageManager.create_page(user.id, name, description, profile_img_url, cover_img_url)
        return redirect(url_for('view_page', page_id=page.id))
    return render_template('create_page.html', user=user)

@app.route('/page/<int:page_id>')
def view_page(page_id):
    page = PageManager.get_page(page_id)
    if not page:
        abort(404)
    return render_template('view_page.html', page=page)

@app.route('/page/<int:page_id>/post/create', methods=['GET', 'POST'])
def create_post(page_id):
    user = get_current_user()
    page = PageManager.get_page(page_id)
    if not page:
        abort(404)
    if request.method == 'POST':
        content = request.form['content']
        PageManager.add_post_to_page(page_id, user.id, content)
        return redirect(url_for('view_page', page_id=page_id))
    return render_template('create_post.html', page=page, user=user)

if __name__ == "__main__":
    app.run(debug=True)
