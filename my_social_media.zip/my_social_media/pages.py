from models import db, Page, Post, User
from datetime import datetime
from typing import Optional

class PageManager:
    @staticmethod
    def create_page(owner_id: int, name: str, description: str = "", profile_img_url: str = "", cover_img_url: str = "") -> Page:
        page = Page(
            owner_id=owner_id,
            name=name,
            description=description,
            profile_img_url=profile_img_url,
            cover_img_url=cover_img_url
        )
        db.session.add(page)
        db.session.commit()
        return page

    @staticmethod
    def get_page(page_id: int) -> Optional[Page]:
        return Page.query.get(page_id)

    @staticmethod
    def add_post_to_page(page_id: int, author_id: int, content: str) -> Optional[Post]:
        page = Page.query.get(page_id)
        if not page:
            return None
        post = Post(page_id=page_id, author_id=author_id, content=content, created_at=datetime.utcnow())
        db.session.add(post)
        db.session.commit()
        return post

    @staticmethod
    def list_pages_by_owner(owner_id: int):
        return Page.query.filter_by(owner_id=owner_id).all()
